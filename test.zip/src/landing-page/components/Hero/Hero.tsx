import { ArrowRight } from "lucide-react";
import { useAuth } from "wasp/client/auth";
import { Link as WaspRouterLink, routes } from "wasp/client/router";
import { Button } from "../../../client/components/ui/button";
import { AppName, AppTagline } from "../../../shared/common";
import { Orbit } from "./Orbit";

export function Hero() {
  const { data: user } = useAuth();

  return (
    <div className="relative w-full overflow-x-clip pt-12">
      <TopGradient />
      <BottomGradient />
      <div className="mx-auto flex max-w-7xl flex-col pt-20 lg:flex-row">
        <div className="py-24 sm:py-32">
          <div className="max-w-8xl px-6 lg:px-8">
            <div className="lg:mb-18 mx-auto max-w-3xl text-center md:text-left">
              <span className="border-border bg-card-subtle text-muted-foreground mb-4 inline-block rounded-full border px-3 py-1 text-xs font-semibold tracking-wider uppercase">
                {AppName} · Satisfaction Client
              </span>
              <h1 className="text-foreground text-5xl font-extrabold leading-none md:text-6xl">
                Écoutez{" "}
                <span className="text-gradient-primary font-black">
                  chaque client
                </span>
                , même sans smartphone
              </h1>
              <p className="text-md text-muted-foreground mt-6 max-w-2xl font-mono leading-8">
                {AppTagline}
              </p>
              <div className="mt-10 flex items-center justify-center gap-x-6 md:justify-start">
                <Button size="lg" variant="outline" asChild>
                  <WaspRouterLink
                    to={user ? routes.AccountRoute.to : routes.SignupRoute.to}
                  >
                    Essayer gratuitement
                  </WaspRouterLink>
                </Button>
                <Button size="lg" variant="default" asChild>
                  <a href="#features">
                    Découvrir les fonctionnalités
                    <ArrowRight />
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
        <div className="hidden lg:block">
          <Orbit />
        </div>
      </div>
    </div>
  );
}

function TopGradient() {
  return (
    <div
      className="absolute right-0 top-0 -z-10 w-full transform-gpu overflow-hidden blur-3xl sm:top-0"
      aria-hidden="true"
    >
      <div
        className="aspect-1020/880 bg-linear-to-tr w-[70rem] flex-none from-amber-400 to-purple-300 opacity-10 sm:right-1/4 sm:translate-x-1/2 dark:hidden"
        style={{
          clipPath:
            "polygon(80% 20%, 90% 55%, 50% 100%, 70% 30%, 20% 50%, 50% 0)",
        }}
      />
    </div>
  );
}

function BottomGradient() {
  return (
    <div
      className="absolute inset-x-0 top-[calc(100%-40rem)] -z-10 transform-gpu overflow-hidden blur-3xl sm:top-[calc(100%-65rem)]"
      aria-hidden="true"
    >
      <div
        className="aspect-1020/880 bg-linear-to-br relative w-[90rem] from-amber-400 to-purple-300 opacity-10 sm:-left-3/4 sm:translate-x-1/4 dark:hidden"
        style={{
          clipPath: "ellipse(80% 30% at 80% 50%)",
        }}
      />
    </div>
  );
}
