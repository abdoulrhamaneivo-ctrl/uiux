export { Hero } from "./Hero";
