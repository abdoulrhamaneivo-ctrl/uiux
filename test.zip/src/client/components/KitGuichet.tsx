import React, { useRef } from 'react';
import { toPng } from 'html-to-image';
import { Download, Share2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from './ui/button';

export const KitGuichet = ({ guichet }: { guichet: any }) => {
  const kitRef = useRef<HTMLDivElement>(null);
  const evalUrl = `https://cxsat.ci/q/${guichet.id}`;
  const ussdCode = `*789*42*${guichet.id}#`;

  const downloadKit = () => {
    if (kitRef.current) {
      toPng(kitRef.current).then((dataUrl) => {
        const link = document.createElement('a');
        link.download = `kit-cxsat-${guichet.nom_guichet}.png`;
        link.href = dataUrl;
        link.click();
      });
    }
  };

  return (
    <div className="space-y-4">
      <div ref={kitRef} className="bg-card p-8 border-2 border-border rounded-xl w-72 shadow-xl mx-auto">
        <h2 className="text-center font-bold text-lg mb-2 text-foreground">{guichet.nom_guichet}</h2>
        <img
          src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(evalUrl)}`}
          alt="QR"
          className="mx-auto"
        />
        <div className="mt-4 text-center">
          <p className="text-xs text-muted-foreground">Sans internet ? Composez {ussdCode}</p>
          <p className="mt-1 inline-block rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            Bientôt disponible
          </p>
        </div>
      </div>
      <div className="flex gap-2 justify-center">
        <motion.div whileTap={{ scale: 0.95 }}>
          <Button onClick={downloadKit} className="gap-2">
            <Download size={16} /> Télécharger l'image
          </Button>
        </motion.div>
        <motion.div whileTap={{ scale: 0.95 }}>
          <Button variant="outline" onClick={() => navigator.clipboard.writeText(evalUrl)} className="gap-2">
            <Share2 size={16} /> Copier le lien
          </Button>
        </motion.div>
      </div>
    </div>
  );
};
