import React, { useState } from 'react';
import { useAuth } from 'wasp/client/auth';
import {
  useQuery,
  createAgent,
  updateAgent,
  deleteAgent,
  getAgentsByAgence,
  getAgences,
} from 'wasp/client/operations';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users,
  UserPlus,
  Pencil,
  Trash2,
  CheckCircle2,
  UsersRound,
} from 'lucide-react';
import { AmbientBackground } from '../components/AmbientBackground';
import { PageHeader } from '../components/PageHeader';
import { MotionCard } from '../components/MotionCard';
import { EmptyState } from '../components/EmptyState';
import { FormField } from '../components/FormField';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';

export const AdminPersonnelPage = () => {
  const { data: user } = useAuth();
  const [selectedAgenceId, setSelectedAgenceId] = useState<number>(
    user?.id_agence ?? 1,
  );
  const { data: agents } = useQuery(getAgentsByAgence, {
    id_agence: selectedAgenceId,
  });
  const { data: agences } = useQuery(getAgences);
  const [formData, setFormData] = useState({
    nom: '',
    prenom: '',
    email: '',
    telephone: '',
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await updateAgent({ id: editingId, ...formData, id_agence: selectedAgenceId });
      } else {
        await createAgent({ ...formData, id_agence: selectedAgenceId });
      }
      setFormData({ nom: '', prenom: '', email: '', telephone: '' });
      setEditingId(null);
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 3000);
    } catch (error) {
      console.error("Erreur lors de la création ou de la mise à jour de l'agent", error);
    }
  };

  const handleEdit = (agent: any) => {
    setEditingId(agent.id);
    setFormData({
      nom: agent.nom,
      prenom: agent.prenom,
      email: agent.email || '',
      telephone: agent.telephone || '',
    });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setFormData({ nom: '', prenom: '', email: '', telephone: '' });
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteAgent({ id });
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 3000);
    } catch (error) {
      console.error("Erreur lors de la suppression de l'agent", error);
    }
  };

  const agentCount = agents?.length ?? 0;

  return (
    <AmbientBackground>
      <div className="mx-auto max-w-5xl p-6 lg:p-10">
        <PageHeader
          icon={Users}
          eyebrow="Équipe"
          title="Gestion du personnel"
          description="Ajoutez, modifiez et suivez les agents rattachés à votre agence."
          actions={
            user?.role === 'DIRECTION' && agences ? (
              <Select
                value={String(selectedAgenceId)}
                onValueChange={(v) => setSelectedAgenceId(Number(v))}
              >
                <SelectTrigger className="h-10 min-w-56">
                  <SelectValue placeholder="Choisir l'agence" />
                </SelectTrigger>
                <SelectContent>
                  {agences.map((agence: any) => (
                    <SelectItem key={agence.id} value={String(agence.id)}>
                      {agence.nom_agence} ({agence.commune})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : undefined
          }
        />

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_1.1fr]">
          {/* Formulaire d'ajout d'agent */}
          <MotionCard interactive={false} className="h-fit p-6 lg:sticky lg:top-8">
            <div className="mb-5 flex items-center gap-2.5">
              <span className="flex size-9 items-center justify-center rounded-xl bg-secondary/10 text-secondary ring-1 ring-inset ring-secondary/15">
                <UserPlus className="size-5" />
              </span>
              <h2 className="text-title-xsm font-bold text-foreground">
                {editingId ? 'Modifier un agent' : 'Ajouter un agent'}
              </h2>
            </div>

            <AnimatePresence>
              {submitted && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mb-4 flex items-center gap-2 rounded-xl bg-success/10 p-3 text-sm font-medium text-success"
                >
                  <CheckCircle2 className="size-4" /> Opération réussie !
                </motion.div>
              )}
            </AnimatePresence>

            <form onSubmit={handleSubmit} className="grid gap-4 sm:grid-cols-2">
              <FormField label="Prénom" htmlFor="prenom" required>
                <Input
                  id="prenom"
                  name="prenom"
                  placeholder="Prénom"
                  value={formData.prenom}
                  onChange={handleInputChange}
                  required
                  className="h-11"
                />
              </FormField>
              <FormField label="Nom" htmlFor="nom" required>
                <Input
                  id="nom"
                  name="nom"
                  placeholder="Nom"
                  value={formData.nom}
                  onChange={handleInputChange}
                  required
                  className="h-11"
                />
              </FormField>
              <FormField label="Email" htmlFor="email" required className="sm:col-span-2">
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="agent@entreprise.ci"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className="h-11"
                />
              </FormField>
              <FormField label="Téléphone" htmlFor="telephone" className="sm:col-span-2">
                <Input
                  id="telephone"
                  name="telephone"
                  type="tel"
                  placeholder="+225 ..."
                  value={formData.telephone}
                  onChange={handleInputChange}
                  className="h-11"
                />
              </FormField>

              <div className="flex gap-3 sm:col-span-2">
                {editingId && (
                  <Button type="button" variant="outline" onClick={handleCancelEdit}>
                    Annuler
                  </Button>
                )}
                <motion.div whileTap={{ scale: 0.98 }} className="flex-1">
                  <Button type="submit" className="w-full">
                    {editingId ? 'Enregistrer' : 'Ajouter'}
                  </Button>
                </motion.div>
              </div>
            </form>
          </MotionCard>

          {/* Liste des agents */}
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-title-sm font-bold text-foreground">Agents actuels</h2>
              {agentCount > 0 && (
                <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
                  {agentCount} agent{agentCount > 1 ? 's' : ''}
                </span>
              )}
            </div>

            {agentCount > 0 ? (
              <div className="space-y-3">
                {agents!.map((agent: any, i: number) => (
                  <motion.div
                    key={agent.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: i * 0.04 }}
                  >
                    <MotionCard interactive={false} className="p-4">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <span className="flex size-11 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
                            {agent.prenom?.[0]}
                            {agent.nom?.[0]}
                          </span>
                          <div className="text-sm">
                            <p className="font-semibold text-foreground">
                              {agent.prenom} {agent.nom}
                            </p>
                            <p className="text-xs text-muted-foreground">{agent.role}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(agent)}
                            aria-label="Modifier"
                            className="text-warning hover:bg-warning/10 hover:text-warning"
                          >
                            <Pencil className="size-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(agent.id)}
                            aria-label="Supprimer"
                            className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </div>
                      </div>
                    </MotionCard>
                  </motion.div>
                ))}
              </div>
            ) : (
              <EmptyState
                icon={UsersRound}
                title="Aucun agent enregistré"
                description="Ajoutez votre premier agent via le formulaire pour commencer à suivre votre équipe."
              />
            )}
          </div>
        </div>
      </div>
    </AmbientBackground>
  );
};
